# MDC-Web with aurelia-skeleton-webpack

## Running the app

To run the app execute the following command:

```shell
npm install
npm start
```

This command starts the webpack development server that serves the build bundles.
You can now browse the skeleton app at http://localhost:9000. Changes in the code
will automatically build and reload the app.
