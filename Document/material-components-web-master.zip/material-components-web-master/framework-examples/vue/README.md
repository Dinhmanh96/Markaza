# MDC-Web Example - Vue

This folder contains an example of using mdc-checkbox within Vue v2.0+. Huge thank you to
@petejohanson for creating this!

## Setup

1. Run `npm install` within this folder
2. Run `npm start` to start the demo server
3. Navigate to http://localhost:8080 to view the demo.
