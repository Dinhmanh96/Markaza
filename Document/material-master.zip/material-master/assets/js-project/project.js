$(function () {

  // project js
  Holder.addTheme('gray', {
    bg: '#757575',
    fg: 'rgba(255,255,255,.7)',
    font: 'Helvetica',
    fontweight: 'normal'
  });

});
